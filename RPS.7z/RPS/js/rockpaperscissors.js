<script src="js/game.js"></script>
<script>
   var x = document.getElementById("wrapper");
   if (x.style.display === "none") {
   x.style.display = "block";
   } else {
   x.style.display = "none";
   }
   
//  declare variables 
    var randomNum = 0;		// Initialize random number 
    var RoundCounter = 0;
    var HumanScore = 0;
    var ComputerScore = 0;

// declare image source arrays: human images, computer images, and rollover images (used by both human and computer)
var srcRollover = [ "images/rock.jpg", "images/paper.jpg", "images/scissors.jpg" ];
var srcHuman = [ "image/rockhuman.jpg", "images/paperhuman.jpg", "images/scissorshuman.jpg" ];
var srcComputer = [ "images/rockcomputer.jpg", "images/papercomputer.jpg", "images/scissorscomputer.jpg" ];

//  declare nodelists
//  the first contains all the human images, the second contains all the computer images
var humanList = document.getElementsByClassName("human");		// Human images
var computerList = document.getElementsByClassName("computer");		// Computer images

// declare event handlers

//  Event handler for clicking on the human image. This is where all the game
//  logic happens: random number generation, game counter, comparing user vs computer selection, etc. 
var clickHandler = function() {
	// 'this' is a reference to the object that currently "owns" this event handler function:
	// You'll need the index of the current image to match against your computer foe
	var i = this.index;

	// Restore default computer image before doing anything else
	computerList[randomNum].src = srcComputer[randomNum];
	
	// generate random number from 0 to 2
	randomNum = Math.floor( Math.random() * 3 );
	
	// Display current computer image using randomNumber as index
	computerList[ randomNum ].src = srcRollover[ randomNum ];
	
	// Put logic here 
	// TIP: Use same game counter code as you used in the Number Guessing Game
    // (instead of 6 tries, you get 10 tries)

    // Human choice and Computer choice are the same
	if (i = 0) && (randomNum = 0) || (i = 1) && (randomNum = 1)  || (i = 2) && (randomNum = 2)
	{ // message it is a tie round
    
	}

    // Rock vs Paper - situations
	if (i = 0) && (randomNum = 1)
	{ // Rock vs Paper - message Computer wins round
	    ComputerScore = ComputerScore + 1;     
	}

	if (i = 1) && (randomNum = 0)
	{ // Paper vs Rock - message Human wins round
	    HumanScore = HumanScore + 1;
	}

    // Rock vs Scissors - situations
	if (i = 0) && (randomNum = 2)
	{ // Rock vs Scissor message Human wins round
	    HumanScore = HumanScore + 1;
	}
	if (i = 2) && (randomNum = 0)
	{ // Scissor vs Rock - message Computer wins round
	    ComputerScore = ComputerScore + 1;
	}

    // Scissor vs Paper - situations
	if (i = 2) && (randomNum = 1)
	{ // Scissor vs Paper - message Human wins round
	    HumanScore = HumanScore + 1;  
	}

	if (i = 2) && (randomNum = 1)
	{ // Paper vs Scissor vs Paper - message Computer wins round

	    ComputerScore = ComputerScore + 1;
	}

 
	RoundCounter = RoundCounter + 1;
	if RoundCounter = 10
	{
	    // game ends
        //
	}

}

//  Mouse over human image
var mouseoverHandler = function() {
	// 'this' is a reference to the object that currently "owns" this event handler function:
	// in other words, the image that the cursor just rolled over
	// (this should be familiar from working on the Car Speedometer exercise in Project 1)
	var i = this.index;
	console.log( this );    // try this for fun
	
	// Set image display to rollover image 
	this.src = srcRollover[i];
}

//  Mouse off human image
var mouseoutHandler = function() {
	// 'this' is a reference to the object that currently "owns" this event handler function:
	// in other words, the image that the cursor just rolled off of
	var i = this.index;
	
	// Reset human and computer images back to default
	this.src = srcHuman[i];
	computerList[ randomNum ].src = srcComputer[ randomNum ];
}

//********************
//  Main Program
//********************

//  Playing the game:AF
//  when user clicks on a human image, do the following:
//  1)  use random number generator to display computer selection 
//  2)  use logic to determine who wins the round: human or computer
//  3)  display results of this round
//  4)  if 10 rounds have passed, turn off event handlers and display Game Over screen
//

//  Loop through nodelist of human image nodes and assign event handlers to each one
//  Once this is done, game playing logic all happens inside of the clickHandler function
for (var i=0; i<humanList.length; i++) {
	var humanNode = humanList[i];
    // set up event handler associations for the image node.
	// Each image will be targeted by 3 events: click, mouseover, and mouseout
	humanNode.onclick = clickHandler;        // image will now respond to click events
	humanNode.onmouseover = mouseoverHandler;    // image will now respond to mouse over events
	humanNode.onmouseout = mouseoutHandler;    // image will now respond to mouse out events
	// add new property to image node to store the index number -- very important!
	humanNode.index = i; 
}    


</script>
